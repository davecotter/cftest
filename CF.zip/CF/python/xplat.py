import sys, platform, subprocess, os, paths, copy

def use_debug_print():
	return False

# =================================================================================
def log_message(message, newlineB=True):

	if newlineB:
		message += '\n'
		
	sys.stderr.write(message)

def log_message_if(shouldB, message, newlineB=True):
	if shouldB:
		log_message(message, newlineB)

# =====================================================
# true is build the Qt version of the app
# false is build the xcode / msdev version
def should_build_Qt(qtB):
	shouldB = False
	
	# normally these are always true, but we can turn
	# them off selectively if we want to skip a 
	# particular build type
	if qtB:
		# should we build the Qt version?
		shouldB = True
	else:
		# should we build the xcode/msdev version?
		shouldB = True

	return shouldB

# true is build the Mac version of the app
# false is build the Windows version
def should_build_platform(macB):
	shouldB = False
	
	# normally these are always true, but we can turn
	# them off selectively if we want to skip a 
	# particular build type
	if macB:
		# should we build the mac version?
		shouldB = True
	else:
		# should we build the win version?
		shouldB = True

	return shouldB

# =================================================================================
def debug_print(str):
	if use_debug_print():
		log_message("xplat: " + str)

def file_create_abs(filePath, contents = ""):
	with open(filePath, "w") as dstFile:
		if contents != "":
			dstFile.write(contents)

def	enable_separate_ppc_builds():
	return False

def build_kit_to_arch(buildKit):
	arch = 'x'
	if buildKit == '32':
		arch += '86'
	else:
		arch += '64'
		
	return arch

def enquote_if(str):
	if ' ' in str:
		str = paths.enquote(str)
	return str

def commandListToString(in_cmdA):
	cmdA = copy.deepcopy(in_cmdA)
	cmdStr = enquote_if(cmdA.pop(0))

	for subCmd in cmdA:
		cmdStr += ' ' + enquote_if(subCmd)

	return cmdStr

def system(cmdA):
	cmdStr = commandListToString(cmdA)
	debug_print(cmdStr)
	os.system(cmdStr)
 
def just_pipe(cmdA, buildKit_optional = '0'):
	debug_print('about to call Popen...');
	debug_print('with cmd: ' + commandListToString(cmdA));
	
	if False and buildKit_optional != '0':
		envPath = paths.enquote(paths.get_win_bin_folder())
		#log_message("adding path: " + envPath)
		my_env["PATH"] = my_env["PATH"] + ';' + envPath
		#log_message("PATH: " + my_env["PATH"])
		pipe = subprocess.Popen(cmdA, shell=True, env=my_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	else:
		has_full_pathB = cmdA[0][1] == ':'
		add_shellB = not has_full_pathB # shell=add_shellB
		pipe = subprocess.Popen(cmdA, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

	return pipe

def pipe(cmd, print_outB = False, only_if_errorB = False, raise_on_errB = True, buildKit_optional = '0'):
	pipe = just_pipe(cmd, buildKit_optional)
	
	debug_print('pipe: about to communicate');
	
	(out, err) = pipe.communicate()

	debug_print('pipe: about to get returncode');

	ret = pipe.returncode
	
	errStr = str(err)

	if errStr != "":
	
		ignoreOutA = [
			"i386 architecture is deprecated",
			"bin/uic"
		]
	
		showOutB = print_outB and out != ""
		
		if showOutB:
			for ignoreOut in ignoreOutA:
				if ignoreOut in out:
					showOutB = False

		if showOutB:
			log_message("out: <\n" + out.rstrip('\n') + "\n> :out")

		ignoreErrsA = [
			'Building bundle', 
			'AcceptPolicy_block_invoke',
			"Cannot find Visual Studio",
			"kCFURLVolumeIsAutomountedKey missing",
			"DTDeviceKit: deviceType from",
			"iPhoneConnect",
			"usr/local/mysql",
			"usr/local/opt/libiodbc",
			"Postgres.app/Contents",
			"i386 architecture is deprecated"
		]

		showErrB = True
		
		for ignoreErr in ignoreErrsA:
			if ignoreErr in errStr:
				showErrB = False

		if showErrB:
			if only_if_errorB:
				showErrB = "error" in errStr
				
			if showErrB:
				log_message("err: <\n" + errStr.rstrip('\n') + "\n> :err")
	
	if raise_on_errB:
		if ret != 0:
			log_message("return value: " + str(ret))
			raise OSError("error in build")
		else:
			debug_print('pipe: success!');
		
	return ret;

def include_separate_ppc_builds():
	return False

def is_mac():
	return platform.system() == 'Darwin'

def is_win():
	return not is_mac()

# =====================================================
def get_os_vers():
	versStr = ''
	
	if is_mac():
		versStr = platform.mac_ver()[0]
	else:
		versStr = platform.win32_ver()[0]
		
	return versStr;
	
def is_host_os(): # as opposed to a VM (guest OS) or Windows
	'''
	if is_mac():
		log_message("it's a mac")
	else:
		log_message("NOT a mac")
	
	log_message(get_os_vers())
	'''
	
	host_vers = get_os_vers();
	
	is_guestB = host_vers == "10.9.5" or host_vers == "10.6.8" or host_vers == "10.16"
	
	'''
	if is_guestB:
		log_message("is guest")
	else:
		log_message("NOT guest")
	'''

	is_hostB = is_win() or not is_guestB
	
	'''
	if is_hostB:
		log_message("is host")
	else:
		log_message("NOT host")
	'''

	return is_hostB

def building_ppc():
	return False

def get_build_folder(forceB = False):
	build_folder = 'build/'
	
	return build_folder

