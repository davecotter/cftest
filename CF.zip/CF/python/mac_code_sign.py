import platform, plistlib, glob
import sys, shutil, os, stat, zipfile
import paths, xplat, post_build_cf

#-----------------------------------------------------
def debug_print(str):
	# xplat.log_message("mac_code_sign: " + str)
	pass

def sign(exePath):
	sign_cmd = ''
	
	# why did i need this?
	#signPath = os.path.abspath("../External/Xcode/codesign_allocate")
	#sign_cmd += 'export CODESIGN_ALLOCATE="' + signPath + '"\n'
	
	# make signatures work on 10.10
	# see https://stackoverflow.com/questions/41865537/how-does-apples-codesign-utility-decide-which-sha-algorithms-to-sign-a-shared
	sign_cmd += 'export  LDFLAGS="-mmacosx-version-min=10.9"\n'
	sign_cmd += 'export   CFLAGS="-mmacosx-version-min=10.9"\n'
	sign_cmd += 'export CXXFLAGS="-mmacosx-version-min=10.9"\n'

	sign_cmd += 'codesign'
	sign_cmd += ' -f'	 									# f = force	(replace existing)
	sign_cmd += ' -s '	+ post_build_cf.get_singing_id()	# s = sign	(using the following cert)
	sign_cmd += ' '		+ paths.enquote(exePath)
	
	debug_print(sign_cmd)
	resultL = os.system(sign_cmd)
	
	if resultL == 0:
		# xplat.log_message("codesigned: " + os.path.basename(os.path.normpath(exePath)))
		pass
	else:
		xplat.log_message("Result: " + str(resultL))
		
		if (resultL == 256):
			raise OSError("Code sign problem.  Growl bundle symlink? Is http://timestamp.apple.com/ down?")
		else:
			raise OSError("other code sign fail")

def recursive_sign(path):
	fileList = os.listdir(path)

	for fileName in fileList:
		if not path.endswith('/'):
			path += '/'
		
		sub_path = path + fileName
		
		is_dirB = os.path.isdir(sub_path)
		
		if not is_dirB or fileName.endswith('.framework'):
			sign(sub_path)
		elif is_dirB:
			recursive_sign(sub_path)

def main(xB, qtB, devDir, edition, buildKit, debugB):

	if debugB:	# or set to 0 to code sign the debug version
		xplat.log_message('Not signing debug app...')
	else:
		appStr = 'kJams '
		
		xplat.log_message('Signing app...')
		
		if xB:
			edition = 'X ' + edition
		
		projName	= appStr + edition						# "kJams Pro"
		projTarget	= projName								# "kJams Pro Debug"
		
		paddleName	= "PaddleServer"
		
		if debugB:
			debugStr = " Debug"
			projTarget += debugStr
			paddleName += debugStr
			
		appName		= projTarget + '.app'					# "kJams Pro Debug.app"
		
		kjamsApp	= devDir
		kjamsApp	+= xplat.get_build_folder()	# "build/"
		
		if qtB:
			kjamsApp += get_plat_kit_str(buildKit) + '/'
		
		kjamsApp	+= appName	# "kJams Pro Debug.app"
		
		if not os.path.exists(kjamsApp):
			xplat.log_message(kjamsApp)
			raise OSError("Code sign problem.  kjamsApp")

		contentsPath		= kjamsApp		+ '/Contents/'
		frameworksPath		= contentsPath	+ 'Frameworks/'
		pluginsPath			= contentsPath	+ 'Plugins/'
		macOSPath			= contentsPath	+ 'MacOS/'
		resPath				= contentsPath	+ 'Resources/'

		signList = []

		if not qtB:
			paddleApp			= resPath + paddleName + '.app'
			paddleFrameworks	= paddleApp + '/Contents/Frameworks/'

			if os.path.exists(paddleFrameworks + 'Paddle.framework'):
				debug_print("found paddle frameworks")

				signList += [
					paddleFrameworks	+ 'Paddle.framework',
					paddleApp
				]
			else:
				xplat.log_message(paddleFrameworks)
				raise OSError("Code sign problem.  failed to find paddleFrameworks")

		xplat.log_message("kjamsApp: " + kjamsApp)
		
		# for Qt, ffmpeg is in macOSPath, not resPath
		# for Qt: no AtomicParsley ?
		
		if qtB:
			recursive_sign(frameworksPath)
			recursive_sign(pluginsPath)
			
			signList += [
				macOSPath		+ 'ffmpeg',
			]
		else:
			signList += [
				macOSPath		+ 'HelperTool',
				macOSPath		+ 'InstallTool',
				resPath			+ 'ffmpeg',
				resPath			+ 'AtomicParsley',
				frameworksPath	+ 'LAME.framework',
				frameworksPath	+ 'Growl-123.framework',
				frameworksPath	+ 'Growl.framework',
				frameworksPath	+ 'libboost_atomic.dylib',
				frameworksPath	+ 'libboost_system.dylib',
				frameworksPath	+ 'libboost_thread.dylib',
				frameworksPath	+ 'libgnsdk_musicid.3.2.0.dylib',
				frameworksPath	+ 'libgnsdk_manager.3.2.0.dylib',
			]
		
		signList += [
			kjamsApp
		]
		
		post_build_cf.strip_xattr(kjamsApp)
		
		xplat.log_message('signing --------------')
		
		for exePath in signList:
			sign(exePath)
			xplat.log_message('----------------------')
	
#-----------------------------------------------------
if __name__ == "__main__":
	args = sys.argv[1:]
	
	if len(args) != 1:
		xplat.log_message('No config specified. Use -config $(ConfigurationName) in your commandline arg')
	else:
		target = args[0]
		xplat.log_message('target: ' + target)

 		edition, debugB, framework = paths.target_to_edition(target)
		main(framework == 'X', edition, debugB)

