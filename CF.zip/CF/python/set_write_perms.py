import sys, shutil, os, stat, paths, xplat

def debug_print(str):
	# xplat.log_message("set_write_perms: " + str)
	pass

#-----------------------------------------------------
def shutil_chmod_folder(folderDir):
	write_perm = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH

	fileList = os.listdir(folderDir)

	for fileName in fileList:
		srcPath = folderDir + '/' + fileName
		
		if os.path.isdir(srcPath):
			shutil_chmod_folder(srcPath)
		else:
			perms = os.stat(srcPath)
			os.chmod(srcPath, perms.st_mode | write_perm)

#-----------------------------------------------------
def main(edition, debugB):

	if debugB:
		targetName = ' Debug'
	else:
		targetName = ''

	projName	= 'kJams ' + edition					# "kJams Pro"
	projTarget	= projName + targetName					# "kJams Pro Debug"
	appName		= projTarget + '.app'					# "kJams Pro Debug.app"
	targetApp	= 'build' + '/' + appName		# "build/kJams Pro Debug.app"

	if not os.path.exists(targetApp):
		projName	= 'kJams X ' + edition					# "kJams X Pro"
		projTarget	= projName + targetName					# "kJams X Pro Debug"
		appName		= projTarget + '.app'					# "kJams X Pro Debug.app"
		targetApp	= 'build' + '/' + appName		# "build/kJams X Pro Debug.app"

	if not os.path.exists(targetApp):
		return

	destRes		= targetApp + '/Contents/Resources'
	
	if not os.path.exists(destRes):
		return
	
	xplat.log_message('chmoding Resources...')
	
	xplat.log_message(destRes)
	shutil_chmod_folder(destRes)
	
#-----------------------------------------------------
if __name__ == "__main__":
	args = sys.argv[1:]
	
	if len(args) != 1:
		xplat.log_message('No config specified. Use -config $(ConfigurationName) in your commandline arg')
	else:
		target = args[0]
		xplat.log_message('target: ' + target)
		
		edition, debugB, framework = paths.target_to_edition(target)
		main(edition, debugB)

