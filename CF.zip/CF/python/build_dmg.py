import sys, os, time, mac_code_sign
import paths, xplat
			
###########################################################
def debug_log(str):
	# xplat.log_message("\t\t" + str)
	pass

def create(edition, buildKit, is_qtB = False):
	xplat.log_message('\tCreating DMG...')
	
	editionName			= 'kJams ' + edition
	debug_log('------------ Create DMG: ' + editionName + ' ---------------')
	
	# don't change this string without changing it in "Standard.cpp"
	install_kJams		= 'Install kJams'
	volumesFolder		= '/Volumes/'
	destFolder			= volumesFolder + install_kJams
	devFolder			= paths.get_Development_folder()
	buildFolder			= devFolder
	
	if is_qtB:
		buildFolder		+= 'qt/'

	buildFolder			+= xplat.get_build_folder()

	if is_qtB:
		buildFolder += paths.get_plat_kit_str(buildKit) + '/'
		
	sparseBundleName	= install_kJams + '.sparseimage'
	sparseImagePath		= buildFolder + sparseBundleName;

	############
	debug_log('\tduplicate the sparseimage')
	dmgSrc = os.path.abspath(devFolder + '../dmg/' + sparseBundleName)
	debug_log('dmgSrc: ' + dmgSrc)
	paths.copy_file(dmgSrc, sparseImagePath)

	############
	debug_log('\tmount it')
	os.system("open " + paths.enquote(sparseImagePath))
	while not os.path.exists(destFolder):
		time.sleep(0.5)
	
	# wait just another half second, else we may get a
	# permission denied error when we start the copy?
	time.sleep(0.5)
	
	############
	debug_log('\tcopy "' + editionName + '" to dmg')
	
	editionNameApp = editionName + '.app'
	srcFile = os.path.abspath(buildFolder + editionNameApp)
	os.system('cp -R ' + paths.enquote(srcFile) + ' ' + paths.enquote(destFolder))

	# wait 1/4 second, else we may get a
	# "no mountable file system"
	time.sleep(0.25)

	############
	debug_log('\trename it')
	cmd = ['diskutil', 'rename', install_kJams, install_kJams + ' ' + edition]
	xplat.pipe(cmd)

	# wait 1/4 second, else we may get a
	# "no mountable file system"
	time.sleep(0.25)
	
	############
	debug_log('\tdismount it')
	cmd = ['hdiutil', 'detach', destFolder + ' ' + edition]
	xplat.pipe(cmd)

	# wait 1/4 second, else we may get a
	# "no mountable file system"
	time.sleep(0.25)

	############
	debug_log('\tconvert to compressed')
	zippedEditionName = buildFolder + 'kJams' + edition
	compressedImagePath = zippedEditionName + '.dmg'
	
	cmd = ['hdiutil', 
		'convert', sparseImagePath, 
		'-format', 'UDBZ',
		'-o', compressedImagePath]

	xplat.pipe(cmd)

	############
	debug_log('\tdelete the old sparseimage')
	paths.file_delete(sparseImagePath)
	
	############
	debug_log('\tsigning dmg')
	mac_code_sign.sign(compressedImagePath)

	############
	debug_log('------------ DMG completed ---------------')

	return compressedImagePath;


###########################################################
if __name__ == "__main__":
	args = sys.argv[1:]

	argSizeL = len(args)

	if argSizeL > 1:
		raise OSError('too many arguments')
	elif argSizeL < 1:
		raise OSError('must supply "Edition (configuration)" argument')
	else:
		create(args[0], paths.get_build_kit())

