import os, base64, linecache, stat, shutil, sys, xplat, subprocess

#####################################################
def debug_print(str):
	#xplat.log_message("paths: " + str)
	pass

def debug_print1(str):
	# debug_print(str)
	pass

#####################################################
def	file_delete(fsObj):
	if os.path.exists(fsObj):
		if os.path.isdir(fsObj):
			shutil.rmtree(fsObj, True)
		else:
			os.remove(fsObj)

#####################################################
def reveal(path):
	cmd = []

	if xplat.is_mac():
		cmd += ["open", "-R"]
	else:
		cmd += ["explorer", "/select,"]
		
	cmd += [path]
	subprocess.Popen(cmd)

#####################################################
def	get_script_path(fileStr):
	scriptPath = fileStr
	if scriptPath.find(os.sep) == -1:
		scriptPath = os.getcwd() + os.sep + scriptPath
	return scriptPath

def	get_script_folder(cur_script_path):
	debug_print1("cur_script_path: " + cur_script_path)
	
	scriptFile = os.path.abspath(cur_script_path)
	debug_print1("abs scriptFile : " + scriptFile)
	
	pathStr = get_script_path(scriptFile)
	debug_print1("pathStr        : " + pathStr)
	
	pathStr = os.path.dirname(pathStr)
	debug_print1("pathStr dir    : " + pathStr)
	
	absPath = os.path.abspath(pathStr) + '/'
	debug_print1("absPath        : " + absPath)

	return absPath

def must_exist(filePath):
	if not os.path.exists(filePath):
		filePath = os.path.abspath(filePath)
		raise OSError("file not found: " + filePath)

def force_exist(dst_dir):
	if not os.path.exists(dst_dir):
		os.makedirs(dst_dir)

#####################################################
def get_default_token_str():
	tokenStr  = "lu"
	tokenStr += "na"
	tokenStr += "r_"
	tokenStr += "ec"
	tokenStr += "li"
	tokenStr += "ps"
	tokenStr += "e"
	return tokenStr

def get_token(tokenStr, createB = False):
	# if createB == True, then we create the token file
	
	tokenPath = os.path.expanduser("~")
	tokenPath += "/."
	tokenPath += tokenStr
		
	if createB:							# to create the file, this line = True
		plainText = ''					# and set this line to the password
		tokenCypher = base64.b64encode(plainText)
		xplat.file_create_abs(tokenPath, tokenCypher)

		if xplat.is_win():
			# make the file hidden by default
			subprocess.check_call(["attrib", "+H", tokenPath])
	
	if not os.path.exists(tokenPath):
		raise OSError("Token not found: " + tokenPath)

	resultText = base64.b64decode(linecache.getline(tokenPath, 1).rstrip())

	if createB:
		if plainText != resultText:
			raise OSError("Token creation failed")
		else:
			xplat.log_message("token file created")

	return resultText

#####################################################
# see qt/kjams/kjams.pri, DIR_BOOST
# should match!
def get_boost_vers():
	# only used for Qt builds
	# since the xcode proj has it specified in search paths in the GUI(!)
	'''
		note the xcode project copies "atomic" into the bungle even though it's
		64bit (not fat 32/64).  it's possible we do not need it? but i haven't tried
		removing it. we don't link with it so probably(?) dont need it?
	'''
	return '1_69_0'

# see qt/kjams/kjams.pri, DIR_PADDLE
# should match!
def get_paddle_framework_vers():
	# mac only
	return '4.0.15'

def get_vs_year():
	return '2019'

def get_vcRedist():
	vcRedistDir	= '14.29.30036/'
	return vcRedistDir

# should match what is shown in:
# options-> ??? what?
def get_win_sdk_vers():
	sdkVers		= '10.0.19041.0'
	return sdkVers

def get_program_files_dir():
	return 'C:/Program Files (x86)/'

def get_win10_kit_path():
	return get_program_files_dir() + 'Windows Kits/10/'

def get_win_sdk_path():
	path = get_win10_kit_path()
	path += 'bin' + '/'
	path += get_win_sdk_vers()
	path += '/'
	return path

def get_win_vc_folder():
	path = get_program_files_dir() + 'Microsoft Visual Studio/' + get_vs_year() + '/'
	
	#	this should just find it regardless of VS edition
	if False:
		path += 'Enterprise'
	else:
		path += 'Community'
	
	path += '/VC/'
	return path
	
def get_win_bin_folder():
	path = get_win_vc_folder()
	path += 'Tools/MSVC/' + get_vcRedist() + 'bin/Hostx64/x64/'
	
	return path

###################################################
def get_qt_vers(buildKit):

	if buildKit == 'qt5':
		# temp: i installed a later SDK but haven't switched to it yet
		vers = '5.15.2'
	else:
		dirList = os.listdir(get_qt_IDE_folder())
		#xplat.log_message('dir list:', dirList)
		dirList = [curName for curName in dirList if unicode(curName[0], "utf-8").isnumeric()]
		dirList.sort()
		#xplat.log_message('numeric list:', dirList)
		vers = dirList[-1]

	return vers

def get_qt_IDE_folder(buildKit = 'null'):
	# return the folder that "Qt Creator" is contained in
	# if True, then go into the SDK version folder
	qt_IDE_folder	= get_Developer_folder() + 'Qt/'

	if buildKit != 'null':
		qt_IDE_folder += get_qt_vers(buildKit) + '/'
	
	return qt_IDE_folder

# def get_IDE_vers(buildKit):
# 	vers = get_qt_vers(buildKit)
# 	vers = vers.replace('.', '_')
# 	vers = '-Desktop_Qt_' + vers + '_'
# 	return vers;

def get_editions(include_testB = False):
	editions = ['Lite', 'Pro', '2']
	if include_testB:
		editions += ['Test']
	return editions

def is_debug(str):
	return str.lower() == 'debug'

def is_release(str):
	return str.lower() == 'release'
	
def convert_debug_case(str, upperB = True):
	is_debugB = is_debug(str)
	
	if is_debugB:
	
		if upperB:
			str = 'Debug'
		else:
			str = 'debug'
	else:
		is_releaseB = is_release(str)

		if is_releaseB:
	
			if upperB:
				str = 'Release'
			else:
				str = 'release'
		else:
			raise OSError("build type neither debug nor release")

	return str

def get_build_type(debugB, upperB = False):
	if debugB:
		buildType = 'debug'
	else:
		buildType = 'release'
	
	if upperB:
		buildType = convert_debug_case(buildType)
	
	return buildType

def get_build_kit():
	return 'qt5'
	
def get_plat_kit_str(buildKit):
	str = ''
	
	if xplat.is_mac():
		str += 'mac'
	else:
		str += 'win'

	str += '_' + buildKit
	return str

def enquote(str):
	if '"' not in str:
		str = '"' + str + '"'
	return str

def get_Developer_folder():
	pathStr	= os.path.expanduser("~") + '/Developer/'

	#xplat.log_message("Developer_folder folder: " + pathStr)
	return pathStr

def get_depot_folder():
	pathStr = os.path.abspath(get_script_folder(__file__) + '../..')
	
	# on windows, the depot dir is the root of drive Z, it already has a trailing slash
	# on mac, it needs one
	if xplat.is_mac():
		pathStr += '/'

	return pathStr

def get_CFLite_folder():
	pathStr = get_depot_folder() + 'CF/opencflite-476.17.2/'
	return pathStr
	
def get_CF_proj_folder():
	pathStr = get_CFLite_folder() + 'Qt/CFLite/'
	return pathStr

def get_kJams_folder():
	pathStr = get_depot_folder() + 'kJams/'
	return pathStr

def	get_Development_folder():
	pathStr = get_kJams_folder() + 'Development/'
	return pathStr

def	get_buildFolderParent():
	pathStr = get_Development_folder() + 'qt/'
	return pathStr

def	get_qtProj_folder():
	pathStr = get_buildFolderParent() + 'kJams/'
	return pathStr

###################################################
def copy_file(src_file, dst_object):
	write_perm = stat.S_IWRITE | stat.S_IREAD | stat.S_IROTH
	base_name = os.path.basename(src_file)
#	xplat.log_message('copying file: <' + base_name + '>')
#	xplat.log_message('copy   it to: <' + dst_object + '>')
	shutil.copy(src_file, dst_object)
	
	if os.path.isfile(dst_object):
#		xplat.log_message('file --> ' + dst_object)

		is_exeB = False
		if os.access(src_file, os.X_OK):
			is_exeB = True
			write_perm |= stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
		
		perms = os.stat(dst_object)
		os.chmod(dst_object, perms.st_mode | write_perm)

	else:
		new_dst_obj = dst_object + os.sep + base_name
		new_dst_obj.replace('/', os.sep)
#		xplat.log_message('fldr --> ' + new_dst_obj)
		os.chmod(new_dst_obj, write_perm)

def copy_folder(src_dir, dst_dir):
#	xplat.log_message('copying folder: <' + src_dir + '>')
#	xplat.log_message('copying  it to: <' + dst_dir + '>')
	
	force_exist(dst_dir)
	
#	xplat.log_message('Default encoding: ' + sys.getdefaultencoding())
#	xplat.log_message('FileSys encoding: ' + sys.getfilesystemencoding())
	
#	u_src_dir = unicode(src_dir)
	fileList = os.listdir(src_dir)
#	xplat.log_message('found fileList:')
#	xplat.log_message(fileList)

	for fileName in fileList:
		#if xplat.is_win():
		#	fileName = unicode(fileName.replace(u'\xa7', u'\x15'))
		
		#filenName = unicode(fileName, 'latin1')
		#xplat.log_message(fileName)
		
		srcPath = src_dir + '/' + fileName
		new_dst_obj = dst_dir + '/' + fileName
		
	#	xplat.log_message('copying to: ' + new_dst_obj)
		
		if os.path.isdir(srcPath):
#			xplat.log_message('<' + fileName + '> is a folder')
			copy_folder(srcPath, new_dst_obj)
		else:
#			xplat.log_message('<' + fileName + '> is a file')
			copy_file(srcPath, new_dst_obj)

# src_dir has a trailing /, dst_dir does NOT
def merge_langs(stringFileName, src_dir, dst_dir):
#	xplat.log_message('copying folder: <' + src_dir + '>')
#	xplat.log_message('copying  it to: <' + dst_dir + '>')
	
	must_exist(dst_dir)
	
#	xplat.log_message('Default encoding: ' + sys.getdefaultencoding())
#	xplat.log_message('FileSys encoding: ' + sys.getfilesystemencoding())
	
#	u_src_dir = unicode(src_dir)
	fileList = os.listdir(src_dir)
#	xplat.log_message('found fileList:')
#	xplat.log_message(fileList)

	for fileName in fileList:		
		srcPath = src_dir + fileName
		
		if os.path.isdir(srcPath):
			stringFileNAmeStr = '/' + stringFileName + '.strings'
			srcPath += stringFileNAmeStr
			new_dst_obj = dst_dir + '/' + fileName + stringFileNAmeStr
			
		#	xplat.log_message('copying to: ' + new_dst_obj)
			
			if os.path.isdir(srcPath):
	#			xplat.log_message('<' + fileName + '> is a folder')
				raise OSError("should be no folders in a lang folder")
			else:
	#			xplat.log_message('<' + fileName + '> is a file')
				copy_file(srcPath, new_dst_obj)

# target aka projName
def target_to_edition(target):
	# edition, debugB, framework = target_to_edition(target)

	debugB = False

	if target.endswith('Debug'):
		debugB = True
		
	if 'Lite' in target:
		edition = 'Lite'
	elif 'Pro' in target:
		edition = 'Pro'
	elif '2' in target:
		edition = '2'
	elif 'Test' in target:
		edition = 'Test'
	else:
		raise OSError("invalid kJams edition: " + projName)
		
	if 'X' in target:
		framework = 'X'	#	yaaf
	elif 'Q' in target:
		framework = 'Q'	#	yaaf
	else:
		framework = ''

	return edition, debugB, framework

# target aka projName
def edition_to_target(edition, debugB = False):
	projName = 'kJams '
	projName += edition
	
	if debugB:
		projName += ' Debug'
		
	return projName


if __name__ == "__main__":
	xplat.log_message(get_qt_vers(get_build_kit()))
