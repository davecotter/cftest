import sys, os, subprocess, threading, shutil, time
import paths, xplat, post_build_cf, build_dmg, notarize

def use_debug_print():
	return False
	
def debug_print(str):
	if use_debug_print():
		xplat.log_message("qt_deploy: " + str)

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def log_stderr_blue(msg, newlineB = True):
	if newlineB:
		msg += '\n'

	sys.stderr.write(bcolors.OKCYAN + msg + bcolors.ENDC)

# ===========================================================================
def remove_redist_installer(path):
	if xplat.is_win():
		path = os.path.abspath(path + '/../vc_redist.x64.exe');
		debug_print("checking for redist at path:")
		debug_print(path)

		if os.path.exists(path):
			debug_print("redist EXISTS!")
			paths.file_delete(path)
		else:
			debug_print("redist does not exist")

def get_notarize_password():
	return paths.get_token(paths.get_default_token_str())

def xcode_select(newB):
	use_xcode_selectB = xplat.get_os_vers() == '10.14.6'
	
	# for xcode-select to work without password, you have to edit your 'sudoers' file 
	# https://encyclopediaofdaniel.com/blog/sudo-without-a-password/
	# and add this line at the bottom:
	# %admin ALL=(ALL) NOPASSWD: /usr/bin/xcode-select
	# then type ":x" (or ":wq") (no quotes, then press enter)
	# 'i' to insert text, <esc> to get back to command mode
	# https://www.cs.colostate.edu/helpdocs/vi.html
	
	if use_xcode_selectB:
	
		debug_print("Xcode select new: " + str(use_xcode_selectB))

		if newB:
			xplat.system(['sudo', 'xcode-select', '-s', '/Applications/Xcode_10.3.app/Contents/Developer'])
		else:
			xplat.system(['sudo', 'xcode-select', '-r'])
			
		if use_debug_print():
			xplat.system(['sudo', 'xcode-select', '-p'])

def thread_create_notarized_dmg(edition, dmg_path):
	debug_print('Notarizing ' + edition)

	dict = {
		'proj_name'			: paths.edition_to_target(edition),
		'package'			: dmg_path,
		'username'			: 'icloud@davecotter.com', 
		'password'			: get_notarize_password(),
		'primary_bundle_id'	: 'com.metamuse.kjams' }

	notarize.call(dict)

	paths.must_exist(dmg_path)

	nameStr, extStr = os.path.splitext(os.path.basename(dmg_path))
	nameStr += '_x64' + extStr
	#log_stderr_blue('Moving into place: ' + nameStr)
	
	buildFolderParent = paths.get_Development_folder()
	shutil.move(dmg_path, buildFolderParent + 'build/' + nameStr)
	
def create_notarized_dmg(edition):
	xplat.log_message('creating dmg ' + edition)
	dmg_path = build_dmg.create(edition, True)

	xplat.log_message('Spawning Notarize task: ' + edition)
	threadName = "Notarizer " + edition

	notarize_thread = threading.Thread(			\
		target=thread_create_notarized_dmg, 	\
		name=threadName, args=(edition, dmg_path,))
		
	notarize_thread.start()

	# give time for thread to launch
	# and xcodeselect to have run
	time.sleep(2.5)
	debug_print('notarize done waiting')
	xcode_select(False)
	

def build(buildFolderParent, buildType, buildKit, projName, libPathDir = ""):
	is_debugB	= paths.is_debug(buildType)
	appPath		= post_build_cf.get_app_path(buildFolderParent, buildType, buildKit, projName)
	
	qt_IDE_folder	= paths.get_qt_IDE_folder(buildKit)

	if xplat.is_mac():
		# on mac, bundle has already been created, 
		# but it must be moved into place
		qtDeployExe	= qt_IDE_folder + 'macos/bin/macdeployqt'
		qtDestAppPath = appPath[:-1]
	else:
		qtDeployExe	= qt_IDE_folder + post_build_cf.get_win_compiler_vers(buildKit)
		qtDeployExe += '/bin/windeployqt.exe'
		qtDestAppPath = post_build_cf.get_exe_path(appPath)

	cwd = os.getcwd()
	
	if xplat.is_mac():
		appContainingFolder = os.path.dirname(qtDestAppPath)
		os.chdir(appContainingFolder);
		qtDestAppPath = os.path.basename(qtDestAppPath)

	cmd = [
		qtDeployExe, 
		qtDestAppPath]

	if xplat.is_mac():
	
		if is_debugB:
			# this doesn't seem to help remove the errors about missing sql plugins
			# cmd += ['-use-debug-libs']
			pass

		if libPathDir != "":
			cmd += ['-libpath=' + libPathDir]

		if use_debug_print():
			# cmd += ['-verbose=3']
			pass
		else:
			cmd += ['-verbose=0']

		cmd += [
			'-sign-for-notarization=' + post_build_cf.get_singing_id(),
		]
			
	else:
		cmd += ['--compiler-runtime', '--verbose=0']

	libVers = os.path.basename(qt_IDE_folder[:-1])
		
	xplat.log_message('\tCopying Qt Libraries: ' + libVers + '...')
	debug_print('cmd: ' + str(cmd))
	
	# you will see these problems, which aren't real:		
	'''
	WARNING: Plugin "libqsqlodbc.dylib" uses private API and is not Mac App store compliant.
	WARNING: Plugin "libqsqlpsql.dylib" uses private API and is not Mac App store compliant.
	ERROR: no file at "/usr/local/opt/libiodbc/lib/libiodbc.2.dylib"
	ERROR: no file at "/Applications/Postgres.app/Contents/Versions/9.6/lib/libpq.5.dylib"
	'''
	# note we can't use xplat.pipe, cuz it fails to actually sign the app on mac
	
	if xplat.is_mac():
		xplat.log_message('Note: If you see "ERROR: no file...", you may safely ignore it!')
		
	xplat.system(cmd)
			
	if xplat.is_mac():
	
		# loop unti we get a valid code signature
		while not code_sign_valid(qtDestAppPath):
			xplat.system(cmd)

		os.chdir(cwd);
	else:
		remove_redist_installer(qtDestAppPath)

def code_sign_valid(appPath):
	cmd = ['codesign', '--verify', appPath]
	retVal = xplat.pipe(cmd, False, False, False)
	validB = retVal == 0
	messageStr = 'code signature '
	if validB:
		messageStr += "valid"
	else:
		messageStr += "INVALID. Trying again..."

	xplat.log_message(messageStr)
	return retVal == 0

#-----------------------------------------------------
# args: 

# opt 1: just build and notarize the dmg
# 0: Lite / Pro / 2:

# opt 2: run qtdeploy and ensure code signing is valid
# 0: buildKit
# 1: kJams
# 2: Lite / Pro / 2
# 3: Debug (optional: Release if not set)


if __name__ == "__main__":
	debug_print("running");
	args = sys.argv[1:]
	
	lenI = len(args)

	buildKit	= args[0]
	
	if lenI != 4 and lenI != 3:
		if lenI == 1 and args[0] in paths.get_editions():
			edition = args[0]
			thread_create_notarized_dmg(edition)
		else:
			xplat.log_message('args: ' + str(args))
			raise OSError('qt_deploy: args not correctly specified.')
	else:
		if (lenI == 4):
			debugB = True
			projName += ' ' + args[3]
		else:
			debugB = False

		edition		= args[2]
		projName	= paths.edition_to_target(edition, debugB)

		debug_print("projName: " + projName)
		buildType = paths.get_build_type(debugB)
		build(paths.get_buildFolderParent(), buildType, buildKit, projName)

